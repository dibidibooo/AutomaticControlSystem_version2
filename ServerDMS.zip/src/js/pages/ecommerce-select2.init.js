// Select2
$(".select2").select2();