//Bootstrap-TouchSpin
$("input[name='demo_vertical']").TouchSpin({
    verticalbuttons: true
});