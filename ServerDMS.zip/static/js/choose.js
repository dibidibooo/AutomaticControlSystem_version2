$(function() {
    $('#componentcard11').hide();
    $('#plant_unit1').change(function() {
        if ($('#plant_unit1').val() == '1') {
            $('#componentcard11').show();
        } else {
            $('#componentcard11').hide();
        }
    });
});

$(function() {
    $('#componentcard12').hide();
    $('#plant_unit1').change(function() {
        if ($('#plant_unit1').val() == '2') {
            $('#componentcard12').show();
        } else {
            $('#componentcard12').hide();
        }
    });
});

$(function() {
    $('#componentcard13').hide();
    $('#plant_unit1').change(function() {
        if ($('#plant_unit1').val() == '3') {
            $('#componentcard13').show();
        } else {
            $('#componentcard13').hide();
        }
    });
});

$(function() {
    $('#componentcard14').hide();
    $('#plant_unit1').change(function() {
        if ($('#plant_unit1').val() == '3.1') {
            $('#componentcard14').show();
        } else {
            $('#componentcard14').hide();
        }
    });
});

$(function() {
    $('#componentcard21').hide();
    $('#plant_unit2').change(function() {
        if ($('#plant_unit2').val() == '4') {
            $('#componentcard21').show();
        } else {
            $('#componentcard21').hide();
        }
    });
});

$(function() {
    $('#componentcard22').hide();
    $('#plant_unit2').change(function() {
        if ($('#plant_unit2').val() == '5') {
            $('#componentcard22').show();
        } else {
            $('#componentcard22').hide();
        }
    });
});

$(function() {
    $('#componentcard23').hide();
    $('#plant_unit2').change(function() {
        if ($('#plant_unit2').val() == '5.1') {
            $('#componentcard23').show();
        } else {
            $('#componentcard23').hide();
        }
    });
});


$(function() {
    $('#componentcard311').hide();
    $('#plant_unit3').change(function() {
        if ($('#plant_unit3').val() === '61') {
            $('#componentcard311').show();
        } else {
            $('#componentcard311').hide();
        }
    });
});


$(function() {
    $('#componentcard31').hide();
    $('#unit').change(function() {
        if ($('#plant_unit3').val() === '6' && $('#water_type3').val() === '1') {
            $('#componentcard31').show();
        } else {
            $('#componentcard31').hide();
        }
    });
});

$(function() {
    $('#componentcard32').hide();
    $('#unit').change(function() {
        if ($('#plant_unit3').val() === '6' && $('#water_type3').val() === '2') {
            $('#componentcard32').show();
        } else {
            $('#componentcard32').hide();
        }
    });
});

$(function() {
    $('#componentcard33').hide();
    $('#plant_unit3').change(function() {
        if ($('#plant_unit3').val() === '6.1') {
            $('#componentcard33').show();
        } else {
            $('#componentcard33').hide();
        }
    });
});

$(function() {
    $('#componentcard41').hide();
    $('#plant_unit4').change(function() {
        if ($('#plant_unit4').val() == '7') {
            $('#componentcard41').show();
        } else {
            $('#componentcard41').hide();
        }
    });
});

$(function() {
    $('#componentcard42').hide();
    $('#plant_unit4').change(function() {
        if ($('#plant_unit4').val() == '8') {
            $('#componentcard42').show();
        } else {
            $('#componentcard42').hide();
        }
    });
});

$(function() {
    $('#componentcard43').hide();
    $('#plant_unit4').change(function() {
        if ($('#plant_unit4').val() == '9') {
            $('#componentcard43').show();
        } else {
            $('#componentcard43').hide();
        }
    });
});

$(function() {
    $('#componentcard44').hide();
    $('#plant_unit4').change(function() {
        if ($('#plant_unit4').val() == '10') {
            $('#componentcard44').show();
        } else {
            $('#componentcard44').hide();
        }
    });
});

$(function() {
    $('#componentcard45').hide();
    $('#plant_unit4').change(function() {
        if ($('#plant_unit4').val() == '11') {
            $('#componentcard45').show();
        } else {
            $('#componentcard45').hide();
        }
    });
});

$(function() {
    $('#componentcard46').hide();
    $('#plant_unit4').change(function() {
        if ($('#plant_unit4').val() == '11.1') {
            $('#componentcard46').show();
        } else {
            $('#componentcard46').hide();
        }
    });
});

$(function() {
    $('#componentcard51').hide();
    $('#plant_unit5').change(function() {
        if ($('#plant_unit5').val() == '12') {
            $('#componentcard51').show();
        } else {
            $('#componentcard51').hide();
        }
    });
});

$(function() {
    $('#componentcard61').hide();
    $('#plant_unit6').change(function() {
        if ($('#plant_unit6').val() == '13') {
            $('#componentcard61').show();
        } else {
            $('#componentcard61').hide();
        }
    });
});

$(function() {
    $('#componentcard62').hide();
    $('#plant_unit6').change(function() {
        if ($('#plant_unit6').val() == '14') {
            $('#componentcard62').show();
        } else {
            $('#componentcard62').hide();
        }
    });
});

$(function() {
    $('#componentcard63').hide();
    $('#plant_unit6').change(function() {
        if ($('#plant_unit6').val() == '15') {
            $('#componentcard63').show();
        } else {
            $('#componentcard63').hide();
        }
    });
});

$(function() {
    $('#componentcard64').hide();
    $('#plant_unit6').change(function() {
        if ($('#plant_unit6').val() == '16') {
            $('#componentcard64').show();
        } else {
            $('#componentcard64').hide();
        }
    });
});